Likelandi — Pack para subir (iPhone)
====================================
1) Abrí https://github.com/Likelandi/Likelandi.github.io/upload/main
2) Arrastrá TODO este ZIP. Commit changes.
3) Probá: https://likelandi.github.io/landias-musik.html?v=logo9
4) En tu index.html:
   - Abrí index-hero-snippet.html y copiá lo que hay adentro donde quieras el HERO + favicon.
   - Verificá el botón 'Landia’s Musik'.
5) Instagram correcto: https://instagram.com/likelandii
